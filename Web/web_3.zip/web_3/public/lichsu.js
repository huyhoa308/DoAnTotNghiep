document.addEventListener('DOMContentLoaded', () => {
    const dataSelect = document.getElementById('dataSelect');
    const dateSelect = document.getElementById('dateSelect');
    const commandTypeSelect = document.getElementById('commandTypeSelect');
    const messageDiv = document.getElementById('message');
    const tableHeader = document.getElementById('tableHeader');
    const dataTable = document.getElementById('dataTable');

    // Clock
    function updateClock() {
        const now = new Date();
        const time = now.toLocaleTimeString('vi-VN', { hour12: false });
        const date = now.toLocaleDateString('vi-VN');
        document.getElementById("clock").innerHTML = `${time}   |   ${date}`;
    }
    setInterval(updateClock, 1000);
    updateClock();

    // Load available dates
    function loadDates() {
        fetch('/getDates')
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json();
            })
            .then(dates => {
                console.log('Dates received:', dates);
                dateSelect.innerHTML = '<option value="all">Tất cả ngày</option>';
                dates.forEach(date => {
                    const option = document.createElement('option');
                    option.value = date; // Lưu giá trị YYYY-MM-DD
                    option.textContent = formatDateForDisplay(date); // Hiển thị DD-MM-YYYY
                    dateSelect.appendChild(option);
                });
                loadData();
            })
            .catch(error => {
                console.error('Error loading dates:', error);
                messageDiv.textContent = 'Lỗi khi tải danh sách ngày: ' + error.message;
            });
    }

    // Format date for display (YYYY-MM-DD to DD-MM-YYYY)
    function formatDateForDisplay(date) {
        const parts = date.split('-');
        return `${parts[2]}-${parts[1]}-${parts[0]}`;
    }

    // Format timestamp (YYYY-MM-DD HH:MM:SS to DD-MM-YYYY HH:MM:SS)
    function formatTimestamp(timestamp) {
        const date = new Date(timestamp);
        return date.toLocaleString('en-GB', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false
        }).replace(/(\d+)\/(\d+)\/(\d+),/, '$1-$2-$3');
    }

    // Toggle command type dropdown visibility
    function toggleCommandTypeSelect() {
        const commandTypeContainer = document.getElementById('commandTypeContainer');
        if (dataSelect.value === 'controlcommands') {
            commandTypeContainer.style.display = 'flex';
        } else {
            commandTypeContainer.style.display = 'none';
            commandTypeSelect.value = 'all'; // Reset when not visible
        }
    }

    // Set table headers based on selected data
    function setTableHeaders(dataType) {
        if (dataType === 'trafficdata') {
            tableHeader.innerHTML = `
                <tr>
                    <th>Thời gian</th>
                    <th>Lưu lượng trung bình</th>
                    <th>Tốc độ trung bình</th>
                    <th>Số xe máy</th>
                    <th>Số ô tô</th>
                    <th>Số xe buýt</th>
                    <th>Thời gian đỏ</th>
                    <th>Thời gian vàng</th>
                    <th>Thời gian xanh</th>
                </tr>
            `;
        } else {
            tableHeader.innerHTML = `
                <tr>
                    <th>Loại lệnh</th>
                    <th>Thời gian đỏ</th>
                    <th>Thời gian vàng</th>
                    <th>Thời gian xanh</th>
                    <th>Thời gian phát</th>
                    <th>Khoảng thời gian</th>
                </tr>
            `;
        }
    }

    // Load data based on filters
    function loadData() {
        const dataType = dataSelect.value;
        let date = dateSelect.value; // Giá trị là YYYY-MM-DD hoặc 'all'
        const commandType = commandTypeSelect.value; // Giá trị là 'auto', 'manual', 'yellow_all' hoặc 'all'
        console.log('Loading data:', { dataType, date, commandType });

        // Cập nhật tiêu đề bảng và thuộc tính data-table
        setTableHeaders(dataType);
        dataTable.setAttribute('data-table', dataType);

        let url = `/getData?table=${dataType}&date=${date}`;
        if (dataType === 'controlcommands' && commandType !== 'all') {
            url += `&command_type=${commandType}`;
        }

        fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                console.log('Data received:', data);
                const tbody = document.querySelector('#dataTable tbody');
                tbody.innerHTML = '';
                if (data.error) {
                    messageDiv.textContent = data.error + (data.details ? ': ' + data.details : '');
                    return;
                }
                if (!Array.isArray(data) || data.length === 0) {
                    messageDiv.textContent = `Không tìm thấy dữ liệu cho bảng "${dataType}" và ngày "${date === 'all' ? 'tất cả' : formatDateForDisplay(date)}"${commandType !== 'all' ? ` với loại lệnh "${commandType}"` : ''}.`;
                    return;
                }
                data.forEach(row => {
                    const tr = document.createElement('tr');
                    if (dataType === 'trafficdata') {
                        tr.innerHTML = `
                            <td>${formatTimestamp(row.timestamp)}</td>
                            <td>${row.avg_traffic_flow}</td>
                            <td>${row.avg_speed}</td>
                            <td>${row.motorcycle_count}</td>
                            <td>${row.car_count}</td>
                            <td>${row.bus_count}</td>
                            <td>${row.red_duration}</td>
                            <td>${row.yellow_duration}</td>
                            <td>${row.green_duration}</td>
                        `;
                    } else {
                        tr.classList.add(row.command_type);
                        tr.innerHTML = `
                            <td>${row.command_type}</td>
                            <td>${row.red_duration}</td>
                            <td>${row.yellow_duration}</td>
                            <td>${row.green_duration}</td>
                            <td>${formatTimestamp(row.issued_at)}</td>
                            <td>${row.time_slot || ''}</td>
                        `;
                    }
                    tbody.appendChild(tr);
                });
                messageDiv.textContent = '';
            })
            .catch(error => {
                console.error('Error loading data:', error);
                messageDiv.textContent = 'Lỗi khi tải dữ liệu: ' + error.message;
            });
    }

    // Update data when filters change
    dataSelect.addEventListener('change', () => {
        toggleCommandTypeSelect();
        loadData();
    });
    dateSelect.addEventListener('change', loadData);
    commandTypeSelect.addEventListener('change', loadData);

    // Initialize command type dropdown
    toggleCommandTypeSelect();

    // Load dates and initial data
    loadDates();
});

// Tab navigation
function setActiveTab(selectedButton, page) {
    if (window.location.pathname.includes(page)) return;
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    selectedButton.classList.add('active');
    window.location.href = page;
}

// Logout
async function logout() {
    try {
        const response = await fetch('/logout', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        const result = await response.json();
        if (response.ok) {
            console.log('Logout successful, redirecting to:', result.redirect);
            window.location.href = result.redirect;
        } else {
            console.error('Logout failed:', result.message);
            alert('Đăng xuất thất bại: ' + result.message);
        }
    } catch (error) {
        console.error('Error during logout:', error);
        alert('Lỗi kết nối khi đăng xuất: ' + error.message);
    }
}