document.addEventListener('DOMContentLoaded', () => {
    // Kiểm tra trạng thái đăng nhập
    fetch('/check-session')
        .then(response => response.json())
        .then(data => {
            if (data.isLoggedIn) {
                console.log('User already logged in, redirecting to index');
                window.location.href = '/index.html';
            }
        })
        .catch(error => console.error('Error checking session:', error));

    const loginForm = document.getElementById('loginForm');
    const messageDiv = document.getElementById('message');

    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        try {
            const response = await fetch('/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
            });
            const result = await response.json();
            if (response.ok) {
                messageDiv.textContent = result.message;
                messageDiv.style.color = 'green';
                console.log('Login successful, redirecting to:', result.redirect);
                window.location.href = result.redirect;
            } else {
                messageDiv.textContent = result.message;
                messageDiv.style.color = 'red';
                console.log('Login failed:', result.message);
            }
        } catch (error) {
            console.error('Error during login:', error);
            messageDiv.textContent = 'Lỗi kết nối server: ' + error.message;
            messageDiv.style.color = 'red';
        }
    });
});