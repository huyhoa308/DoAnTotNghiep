// Clock
function updateClock() {
    let now = new Date();
    let time = now.toLocaleTimeString('vi-VN', { hour12: false });
    let date = now.toLocaleDateString('vi-VN');
    document.getElementById("clock").innerHTML = `${time}   |   ${date}`;
}
setInterval(updateClock, 1000);
updateClock();

// Tab navigation
function setActiveTab(selectedButton, page) {
    if (window.location.pathname.includes(page)) return;
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    selectedButton.classList.add('active');
    window.location.href = page;
}

// Logout
async function logout() {
    try {
        const response = await fetch('/logout', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        const result = await response.json();
        if (response.ok) {
            console.log('Logout successful, redirecting to:', result.redirect);
            window.location.href = result.redirect;
        } else {
            console.error('Logout failed:', result.message);
            alert('Đăng xuất thất bại: ' + result.message);
        }
    } catch (error) {
        console.error('Error during logout:', error);
        alert('Lỗi kết nối khi đăng xuất: ' + error.message);
    }
}

// Update current status
async function updateCurrentStatus() {
    try {
        const response = await fetch('/getCurrentStatus');
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const data = await response.json();
        console.log('Current status data:', data);

        // Cập nhật trạng thái Hướng Bắc-Nam
        const greenNS = data.green_time || 0;
        document.getElementById('currentGreenNS').textContent = `${greenNS} giây`;
        document.getElementById('currentYellowNS').textContent = `${data.yellow_time || 0} giây`;
        document.getElementById('currentRedNS').textContent = `${data.red_time || 0} giây`;
        document.getElementById('currentCycleNS').textContent = `${data.signal_cycle || 1} giây`;

        // Cập nhật trạng thái Hướng Đông-Tây
        const greenEW = 17;
        const yellowEW = 2;
        const redEW = greenNS; // Đèn đỏ EW = Đèn xanh NS
        const cycleEW = greenEW + yellowEW + redEW;
        document.getElementById('currentGreenEW').textContent = `${greenEW} giây`;
        document.getElementById('currentYellowEW').textContent = `${yellowEW} giây`;
        document.getElementById('currentRedEW').textContent = `${redEW} giây`;
        document.getElementById('currentCycleEW').textContent = `${cycleEW} giây`;

        document.getElementById('message').textContent = '';
    } catch (error) {
        console.error('Error fetching current status:', error);
        document.getElementById('message').textContent = 'Lỗi khi tải trạng thái hiện tại: ' + error.message;
    }
}

// Update traffic information
async function updateTrafficInfo() {
    try {
        const response = await fetch('/traffic-data');
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const data = await response.json();
        console.log('Traffic data:', data);
        if (data.length > 0) {
            const latest = data[0];
            document.getElementById('trafficFlow').textContent = `${latest.avg_traffic_flow || 0} xe/phút`;
            document.getElementById('avgSpeed').textContent = `${latest.avg_speed || 0} km/h`;
            document.getElementById('motorcycleCount').textContent = `${latest.motorcycle_count || 0} xe`;
            document.getElementById('carCount').textContent = `${latest.car_count || 0} xe`;
            document.getElementById('busCount').textContent = `${latest.bus_count || 0} xe`;
        } else {
            document.getElementById('trafficFlow').textContent = 'Không có dữ liệu';
            document.getElementById('avgSpeed').textContent = 'Không có dữ liệu';
            document.getElementById('motorcycleCount').textContent = 'Không có dữ liệu';
            document.getElementById('carCount').textContent = 'Không có dữ liệu';
            document.getElementById('busCount').textContent = 'Không có dữ liệu';
        }
        document.getElementById('message').textContent = '';
    } catch (error) {
        console.error('Error fetching traffic data:', error);
        document.getElementById('message').textContent = 'Lỗi khi tải dữ liệu giao thông: ' + error.message;
    }
}

// Update current mode
async function updateCurrentMode() {
    try {
        const response = await fetch('/getMode');
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const data = await response.json();
        console.log('Current mode:', data.mode);
        const modeText = {
            'auto': 'Tự động',
            'manual': 'Thủ công',
            'yellow_all': 'Tất cả đèn vàng'
        };
        document.getElementById('currentMode').textContent = modeText[data.mode] || 'Tự động';
        document.getElementById('message').textContent = '';
    } catch (error) {
        console.error('Error fetching mode:', error);
        document.getElementById('message').textContent = 'Lỗi khi tải chế độ: ' + error.message;
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    updateCurrentStatus();
    updateTrafficInfo();
    updateCurrentMode();
    setInterval(updateCurrentStatus, 2000);
    setInterval(updateTrafficInfo, 2000);
    setInterval(updateCurrentMode, 2000);
});