// Clock
function updateClock() {
    let now = new Date();
    let time = now.toLocaleTimeString('vi-VN', { hour12: false });
    let date = now.toLocaleDateString('vi-VN');
    document.getElementById("clock").innerHTML = `${time}   |   ${date}`;
}
setInterval(updateClock, 1000);
updateClock();

// Tab navigation
function setActiveTab(selectedButton, page) {
    if (window.location.pathname.includes(page)) return;
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    selectedButton.classList.add('active');
    window.location.href = page;
}

// Logout
async function logout() {
    try {
        const response = await fetch('/logout', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        const result = await response.json();
        if (response.ok) {
            console.log('Logout successful, redirecting to:', result.redirect);
            window.location.href = result.redirect;
        } else {
            console.error('Logout failed:', result.message);
            alert('Đăng xuất thất bại: ' + result.message);
        }
    } catch (error) {
        console.error('Error during logout:', error);
        alert('Lỗi kết nối khi đăng xuất: ' + error.message);
    }
}

// Update current status
async function updateCurrentStatus(mode) {
    try {
        const response = await fetch(`/getCurrentStatus?mode=${mode}`);
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const data = await response.json();
        console.log('Current status data:', data);

        // Cập nhật trạng thái Hướng Bắc-Nam
        const greenNS = data.green_time || 0;
        document.getElementById('currentGreenNS').textContent = `${greenNS} giây`;
        document.getElementById('currentYellowNS').textContent = `${data.yellow_time || 0} giây`;
        document.getElementById('currentRedNS').textContent = `${data.red_time || 0} giây`;
        document.getElementById('currentCycleNS').textContent = `${data.signal_cycle || 1} giây`;

        // Cập nhật trạng thái Hướng Đông-Tây
        const greenEW = 17;
        const yellowEW = 2;
        const redEW = greenNS; // Đèn đỏ EW = Đèn xanh NS
        const cycleEW = greenEW + yellowEW + redEW;
        document.getElementById('currentGreenEW').textContent = `${greenEW} giây`;
        document.getElementById('currentYellowEW').textContent = `${yellowEW} giây`;
        document.getElementById('currentRedEW').textContent = `${redEW} giây`;
        document.getElementById('currentCycleEW').textContent = `${cycleEW} giây`;

        document.getElementById('message').textContent = '';
    } catch (error) {
        console.error('Error fetching current status:', error);
        document.getElementById('message').textContent = 'Lỗi khi tải trạng thái hiện tại: ' + error.message;
    }
}

// Load default values for input table
async function loadDefaultValues() {
    try {
        const response = await fetch('/getLatestManualCommands');
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const data = await response.json();
        console.log('Latest manual commands:', data);
        const rows = document.querySelectorAll('#inputTable tbody tr');
        rows.forEach(row => {
            const slot = row.querySelector('.green').dataset.slot;
            const command = data.find(item => item.time_slot === slot);
            const greenInput = row.querySelector('.green');
            const yellowInput = row.querySelector('.yellow');
            const redInput = row.querySelector('.red');
            if (command) {
                greenInput.value = command.green_duration || '';
                yellowInput.value = command.yellow_duration || '';
                redInput.value = command.red_duration || '';
            } else {
                greenInput.value = '';
                yellowInput.value = '';
                redInput.value = '';
            }
        });
    } catch (error) {
        console.error('Error loading default values:', error);
        document.getElementById('message').textContent = 'Lỗi khi tải dữ liệu mặc định: ' + error.message;
    }
}

// Control panel
document.addEventListener('DOMContentLoaded', () => {
    const modeBtn = document.getElementById('modeBtn');
    const yellowAllBtn = document.getElementById('yellowAllBtn');
    const inputTable = document.getElementById('inputTable');
    const applyBtn = document.getElementById('applyBtn');
    const messageDiv = document.getElementById('message');

    let currentMode = 'auto';
    let isYellowAll = false;

    // Load initial mode
    async function initializeMode() {
        try {
            const response = await fetch('/getMode');
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            const data = await response.json();
            console.log('Initial mode:', data.mode);
            currentMode = data.mode || 'auto';
            isYellowAll = currentMode === 'yellow_all';
            setMode(currentMode, isYellowAll);
            await updateCurrentStatus(currentMode);
            await loadDefaultValues();
        } catch (error) {
            console.error('Error loading mode:', error);
            messageDiv.textContent = 'Lỗi khi tải chế độ: ' + error.message;
        }
    }

    initializeMode();

    // Toggle Auto/Manual mode
    modeBtn.addEventListener('click', async () => {
        if (isYellowAll) return; // Không cho phép thay đổi khi yellow_all bật
        currentMode = currentMode === 'auto' ? 'manual' : 'auto';
        modeBtn.disabled = true;
        try {
            const response = await fetch('/saveMode', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ mode: currentMode })
            });
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            const result = await response.json();
            console.log('Mode saved:', result);
            setMode(currentMode, isYellowAll);
            if (currentMode === 'manual' && result.timings) {
                // Cập nhật trạng thái với dữ liệu đèn từ server
                document.getElementById('currentGreenNS').textContent = `${result.timings.green_time || 0} giây`;
                document.getElementById('currentYellowNS').textContent = `${result.timings.yellow_time || 0} giây`;
                document.getElementById('currentRedNS').textContent = `${result.timings.red_time || 0} giây`;
                document.getElementById('currentCycleNS').textContent = `${(result.timings.red_time + result.timings.yellow_time + result.timings.green_time + 1) || 1} giây`;
            }
            await updateCurrentStatus(currentMode);
        } catch (error) {
            console.error('Error saving mode:', error);
            messageDiv.textContent = 'Lỗi khi lưu chế độ: ' + error.message;
        } finally {
            modeBtn.disabled = false;
        }
    });

    // Toggle Yellow All mode
    yellowAllBtn.addEventListener('click', async () => {
        isYellowAll = !isYellowAll;
        currentMode = isYellowAll ? 'yellow_all' : 'auto';
        yellowAllBtn.disabled = true;
        try {
            const response = await fetch('/saveMode', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ mode: currentMode })
            });
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            const result = await response.json();
            console.log('Mode saved:', result);
            setMode(currentMode, isYellowAll);
            await updateCurrentStatus(currentMode);
        } catch (error) {
            console.error('Error saving mode:', error);
            messageDiv.textContent = 'Lỗi khi lưu chế độ: ' + error.message;
        } finally {
            yellowAllBtn.disabled = false;
        }
    });

    // Set mode UI
    function setMode(mode, yellowAll) {
        const inputs = inputTable.querySelectorAll('input');
        if (yellowAll) {
            yellowAllBtn.classList.remove('off');
            yellowAllBtn.classList.add('on');
            modeBtn.disabled = true;
            inputTable.classList.add('disabled');
            inputs.forEach(input => input.disabled = true);
            applyBtn.disabled = true;
        } else {
            yellowAllBtn.classList.remove('on');
            yellowAllBtn.classList.add('off');
            modeBtn.disabled = false;
            if (mode === 'auto') {
                modeBtn.classList.remove('manual');
                modeBtn.classList.add('auto');
                modeBtn.textContent = 'Auto';
                inputTable.classList.add('disabled');
                inputs.forEach(input => input.disabled = true);
                applyBtn.disabled = true;
            } else {
                modeBtn.classList.remove('auto');
                modeBtn.classList.add('manual');
                modeBtn.textContent = 'Manual';
                inputTable.classList.remove('disabled');
                inputs.forEach(input => input.disabled = false);
                applyBtn.disabled = false;
            }
        }
    }

    // Handle Apply button click
    applyBtn.addEventListener('click', async () => {
        const data = [];
        const rows = inputTable.querySelectorAll('tbody tr');

        // Xác định khung giờ hiện tại
        const now = new Date();
        const hours = now.getHours();
        let currentTimeSlot;
        if (hours >= 0 && hours < 6) currentTimeSlot = '0h-6h';
        else if (hours >= 6 && hours < 8) currentTimeSlot = '6h-8h';
        else if (hours >= 8 && hours < 10) currentTimeSlot = '8h-10h';
        else if (hours >= 10 && hours < 12) currentTimeSlot = '10h-12h';
        else if (hours >= 12 && hours < 14) currentTimeSlot = '12h-14h';
        else if (hours >= 14 && hours < 16) currentTimeSlot = '14h-16h';
        else if (hours >= 16 && hours < 18) currentTimeSlot = '16h-18h';
        else if (hours >= 18 && hours < 20) currentTimeSlot = '18h-20h';
        else if (hours >= 20 && hours < 22) currentTimeSlot = '20h-22h';
        else currentTimeSlot = '22h-0h';

        for (const row of rows) {
            const slot = row.querySelector('.green').dataset.slot;
            const green = parseInt(row.querySelector('.green').value) || 0;
            const yellow = parseInt(row.querySelector('.yellow').value) || 0;
            const red = parseInt(row.querySelector('.red').value) || 0;

            data.push({
                slot,
                green_time: green,
                yellow_time: yellow,
                red_time: red,
                signal_cycle: green + yellow + red + 1
            });

            // Cập nhật trạng thái nếu khung giờ khớp với hiện tại
            if (slot === currentTimeSlot) {
                document.getElementById('currentGreenNS').textContent = `${green} giây`;
                document.getElementById('currentYellowNS').textContent = `${yellow} giây`;
                document.getElementById('currentRedNS').textContent = `${red} giây`;
                document.getElementById('currentCycleNS').textContent = `${green + yellow + red + 1} giây`;
            }
        }

        try {
            const response = await fetch('/save', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            const result = await response.json();
            messageDiv.textContent = result.message;
            await updateCurrentStatus(currentMode);
        } catch (error) {
            console.error('Error saving data:', error);
            messageDiv.textContent = 'Lỗi khi lưu dữ liệu: ' + error.message;
        }
    });

    // Gọi hàm cập nhật trạng thái mỗi 2 giây
    setInterval(() => updateCurrentStatus(currentMode), 2000);
});