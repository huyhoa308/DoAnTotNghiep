// Clock
function updateClock() {
    let now = new Date();
    let time = now.toLocaleTimeString('vi-VN', { hour12: false });
    let date = now.toLocaleDateString('vi-VN');
    document.getElementById("clock").innerHTML = `${time}   |   ${date}`;
}
setInterval(updateClock, 1000);
updateClock();

// Tab navigation
function setActiveTab(selectedButton, page) {
    if (window.location.pathname.includes(page)) return;
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    selectedButton.classList.add('active');
    window.location.href = page;
}

// Logout
async function logout() {
    try {
        const response = await fetch('/logout', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        const result = await response.json();
        if (response.ok) {
            console.log('Logout successful, redirecting to:', result.redirect);
            window.location.href = result.redirect;
        } else {
            console.error('Logout failed:', result.message);
            alert('Đăng xuất thất bại: ' + result.message);
        }
    } catch (error) {
        console.error('Error during logout:', error);
        alert('Lỗi kết nối khi đăng xuất: ' + error.message);
    }
}

// Chart
$(document).ready(() => {
    $("#datepicker").datepicker({
        dateFormat: "dd-mm-yy",
        onSelect: function () {
            const date = this.value;
            const parts = date.split('-');
            const day = parts[0];
            const month = parts[1];
            const year = parts[2];
            const fullYear = parseInt(year) < 100 ? `20${year}` : year;
            const formattedDate = `${fullYear}-${month}-${day}`;
            console.log('Fetching traffic flow for date:', formattedDate);
            fetch(`/api/traffic-flow-by-hour?date=${formattedDate}`)
                .then(res => {
                    if (!res.ok) {
                        throw new Error(`HTTP error! Status: ${res.status}`);
                    }
                    return res.json();
                })
                .then(data => {
                    console.log('Traffic flow data:', data);
                    const hours = Array.from({ length: 24 }, (_, i) => i);
                    const traffic = hours.map(h => {
                        const found = data.find(d => d.hour === h);
                        return found ? found.total_traffic_flow : 0;
                    });
                    drawChart(hours, traffic);
                })
                .catch(error => {
                    console.error('Error fetching traffic data:', error);
                    alert('Lỗi khi tải dữ liệu biểu đồ: ' + error.message);
                });
        }
    });
});

let chart;
function drawChart(labels, data) {
    const canvas = document.getElementById('trafficChart');
    const ctx = canvas.getContext('2d');

    if (chart) chart.destroy();

    chart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels.map(h => h + ':00'),
            datasets: [{
                label: 'Tổng lưu lượng giao thông',
                data: data,
                backgroundColor: 'rgba(54, 162, 235, 0.6)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1,
                borderRadius: 5
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    bodyFont: { size: 14 },
                    titleFont: { size: 14 }
                }
            },
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'Giờ trong ngày',
                        font: { size: 16 }
                    },
                    ticks: { font: { size: 14 } }
                },
                y: {
                    title: {
                        display: true,
                        text: 'Tổng lưu lượng giao thông',
                        font: { size: 16 }
                    },
                    ticks: {
                        font: { size: 14 },
                        beginAtZero: true
                    }
                }
            }
        }
    });
}

// Vẽ biểu đồ rỗng khi trang tải
window.addEventListener('DOMContentLoaded', () => {
    const hours = Array.from({ length: 24 }, (_, i) => i);
    const emptyData = Array(24).fill(0);
    drawChart(hours, emptyData);
});