-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: traffic_db
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `control_mode_state`
--

DROP TABLE IF EXISTS `control_mode_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `control_mode_state` (
  `id` int NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `mode` enum('auto','manual') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_timestamp` (`timestamp`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `control_mode_state`
--

LOCK TABLES `control_mode_state` WRITE;
/*!40000 ALTER TABLE `control_mode_state` DISABLE KEYS */;
INSERT INTO `control_mode_state` VALUES (1,'2025-04-16 15:55:20','manual'),(2,'2025-04-16 15:58:11','auto'),(3,'2025-04-16 15:58:40','manual'),(4,'2025-04-16 15:58:41','auto'),(5,'2025-04-16 15:58:43','manual'),(6,'2025-04-16 15:58:44','auto'),(7,'2025-04-16 15:58:44','manual'),(8,'2025-04-16 15:58:44','auto'),(9,'2025-04-16 15:58:45','manual'),(10,'2025-04-16 15:58:45','auto'),(11,'2025-04-16 15:59:05','manual'),(12,'2025-04-16 16:06:54','auto'),(13,'2025-04-16 16:17:34','manual'),(14,'2025-04-16 16:17:35','auto'),(15,'2025-04-16 16:17:35','manual'),(16,'2025-04-16 21:13:55','auto'),(17,'2025-04-16 21:13:55','manual'),(18,'2025-04-16 21:21:40','auto'),(19,'2025-04-16 22:27:31','manual'),(20,'2025-04-16 23:00:06','auto'),(21,'2025-04-16 23:00:07','manual'),(22,'2025-04-16 23:00:09','auto'),(23,'2025-04-16 23:04:19','manual'),(24,'2025-04-18 13:30:22','auto'),(25,'2025-04-18 13:30:56','manual'),(26,'2025-04-18 13:31:01','auto'),(27,'2025-04-18 13:32:29','manual'),(28,'2025-04-18 13:46:09','auto'),(29,'2025-04-18 13:46:10','manual'),(30,'2025-04-18 13:56:00','auto'),(31,'2025-04-18 13:56:02','manual'),(32,'2025-04-18 13:56:03','auto'),(33,'2025-04-18 13:56:04','manual'),(34,'2025-04-18 13:56:13','auto'),(35,'2025-04-18 13:56:44','manual'),(36,'2025-04-18 13:56:44','auto'),(37,'2025-04-18 13:57:52','manual'),(38,'2025-04-18 13:58:17','auto'),(39,'2025-04-18 13:58:18','manual'),(40,'2025-04-18 13:58:25','auto'),(41,'2025-04-18 14:04:30','manual'),(42,'2025-04-18 14:04:33','auto'),(43,'2025-04-18 14:04:43','manual'),(44,'2025-04-18 14:04:49','auto'),(45,'2025-04-18 14:14:44','manual'),(46,'2025-04-18 14:14:45','auto'),(47,'2025-04-18 14:14:46','manual'),(48,'2025-04-18 14:14:48','auto'),(49,'2025-04-18 14:14:49','manual'),(50,'2025-04-18 14:14:50','auto'),(51,'2025-04-18 14:14:50','manual'),(52,'2025-04-18 14:14:51','auto'),(53,'2025-04-18 14:15:08','manual'),(54,'2025-04-18 14:15:09','auto'),(55,'2025-04-18 14:15:09','manual'),(56,'2025-04-18 14:15:10','auto'),(57,'2025-04-18 14:15:12','manual'),(58,'2025-04-18 14:15:13','auto'),(59,'2025-04-19 09:31:36','manual'),(60,'2025-04-19 09:36:19','auto'),(61,'2025-04-19 09:53:38','manual'),(62,'2025-04-19 09:53:39','auto'),(63,'2025-04-19 09:53:40','manual'),(64,'2025-04-19 09:53:41','auto'),(65,'2025-04-19 09:54:01','manual'),(66,'2025-04-19 09:56:14','auto'),(67,'2025-04-19 10:18:39','manual'),(68,'2025-04-19 10:18:41','auto'),(69,'2025-04-19 10:21:52','manual'),(70,'2025-04-19 10:21:53','auto'),(71,'2025-04-20 09:26:58','manual'),(72,'2025-04-20 09:27:00','auto'),(73,'2025-04-20 09:27:01','manual'),(74,'2025-04-20 09:27:01','auto'),(75,'2025-04-20 09:27:03','manual');
/*!40000 ALTER TABLE `control_mode_state` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-20  9:30:22
