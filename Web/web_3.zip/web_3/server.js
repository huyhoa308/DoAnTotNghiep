const express = require('express');
const mysql = require('mysql2');
const mqtt = require('mqtt');
const path = require('path');
const bcrypt = require('bcrypt');
const session = require('express-session');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public'), { index: false }));
app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 }
}));

// Biến toàn cục lưu chế độ hiện tại
let currentMode = 'auto';

// Cấu hình MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '123456',
    database: 'traffic_management'
});

db.connect(err => {
    if (err) {
        console.error('MySQL connection error:', err);
        throw err;
    }
    console.log('MySQL connected');

    // Tạo tài khoản admin nếu chưa tồn tại
    const username = 'admin';
    const password = 'admin123';
    bcrypt.hash(password, 10, (err, hash) => {
        if (err) {
            console.error('Error hashing password:', err);
            throw err;
        }
        db.query(
            'INSERT IGNORE INTO users (username, password) VALUES (?, ?)',
            [username, hash],
            (err) => {
                if (err) console.error('Error creating admin user:', err);
                else console.log('Admin user checked/created');
            }
        );
    });

    // Gửi dữ liệu từ trafficdata sang controlcommands mỗi 5 giây (chỉ khi ở chế độ auto)
    setInterval(() => {
        if (currentMode !== 'auto') {
            console.log('Skipping auto update in non-auto mode');
            return;
        }
        const sqlSelect = `
            SELECT 
                red_duration,
                yellow_duration,
                green_duration
            FROM TrafficData
            WHERE branch_id = 1
            ORDER BY timestamp DESC
            LIMIT 1
        `;
        db.query(sqlSelect, (err, results) => {
            if (err) {
                console.error('Error fetching latest traffic data:', err);
                return;
            }
            if (results.length > 0) {
                const data = results[0];
                const sqlInsert = `
                    INSERT INTO ControlCommands (
                        branch_id, command_type, red_duration, yellow_duration, green_duration, issued_at, time_slot
                    ) VALUES (?, 'auto', ?, ?, ?, NOW(), NULL)
                `;
                db.query(sqlInsert, [1, data.red_duration, data.yellow_duration, data.green_duration], (err) => {
                    if (err) {
                        console.error('Error inserting into ControlCommands:', err);
                    } else {
                        console.log('Latest traffic data inserted into ControlCommands as auto');
                    }
                });
            }
        });
    }, 5000);

    // Gửi dữ liệu đèn đến ESP8266 mỗi 30 giây cho mọi chế độ
    setInterval(() => {
        let sqlSelect, params = [1];
        let red_duration = 0, yellow_duration = 0, green_duration = 0;

        if (currentMode === 'manual') {
            // Xác định khung giờ hiện tại
            const now = new Date();
            const hours = now.getHours();
            let timeSlot;
            if (hours >= 0 && hours < 6) timeSlot = '0h-6h';
            else if (hours >= 6 && hours < 8) timeSlot = '6h-8h';
            else if (hours >= 8 && hours < 10) timeSlot = '8h-10h';
            else if (hours >= 10 && hours < 12) timeSlot = '10h-12h';
            else if (hours >= 12 && hours < 14) timeSlot = '12h-14h';
            else if (hours >= 14 && hours < 16) timeSlot = '14h-16h';
            else if (hours >= 16 && hours < 18) timeSlot = '16h-18h';
            else if (hours >= 18 && hours < 20) timeSlot = '18h-20h';
            else if (hours >= 20 && hours < 22) timeSlot = '20h-22h';
            else timeSlot = '22h-0h';

            // Lấy dữ liệu đèn mới nhất cho khung giờ
            sqlSelect = `
                SELECT red_duration, yellow_duration, green_duration
                FROM ControlCommands
                WHERE branch_id = ?
                AND command_type = 'manual'
                AND time_slot = ?
                ORDER BY issued_at DESC
                LIMIT 1
            `;
            params.push(timeSlot);
        } else if (currentMode === 'auto') {
            // Lấy dữ liệu đèn mới nhất cho chế độ auto
            sqlSelect = `
                SELECT red_duration, yellow_duration, green_duration
                FROM ControlCommands
                WHERE branch_id = ?
                AND command_type = 'auto'
                ORDER BY issued_at DESC
                LIMIT 1
            `;
        } else {
            // Chế độ yellow_all: gửi các giá trị 0
            publishTimingsToESP(0, 0, 0, 'yellow_all');
            return;
        }

        db.query(sqlSelect, params, (err, results) => {
            if (err) {
                console.error('Error fetching latest command for ESP8266:', err);
                return;
            }
            if (results.length > 0) {
                red_duration = results[0].red_duration;
                yellow_duration = results[0].yellow_duration;
                green_duration = results[0].green_duration;
            }
            // Gửi dữ liệu đến ESP8266
            publishTimingsToESP(red_duration, yellow_duration, green_duration, currentMode);
        });
    }, 30000000);
});

// Cấu hình MQTT
const mqttClient = mqtt.connect('mqtt://192.168.125.196:50001');
mqttClient.on('connect', () => {
    console.log('MQTT connected');
    mqttClient.subscribe('traffic/light/esp8266_data');
});

mqttClient.on('error', (err) => {
    console.error('MQTT connection error:', err);
});

mqttClient.on('message', (topic, message) => {
    if (topic === 'traffic/light/esp8266_data') {
        try {
            const data = JSON.parse(message.toString());
            console.log('Received MQTT data:', data);
            const sql = `
                INSERT INTO TrafficData (
                    branch_id, timestamp, avg_traffic_flow, avg_speed, 
                    motorcycle_count, car_count, bus_count, 
                    red_duration, yellow_duration, green_duration
                ) VALUES (?, NOW(), ?, ?, ?, ?, ?, ?, ?, ?)
            `;
            db.query(sql, [
                1, data.avg_traffic_flow, data.avg_speed,
                data.motorcycle_count, data.car_count, data.bus_count,
                data.red_time, data.yellow_time, data.green_time
            ], (err) => {
                if (err) console.error('Error inserting MQTT data:', err);
                else console.log('MQTT data inserted successfully');
            });
        } catch (err) {
            console.error('Error processing MQTT message:', err);
        }
    }
});

// Middleware kiểm tra đăng nhập
function isAuthenticated(req, res, next) {
    if (req.session.user) {
        console.log('User authenticated:', req.session.user.username);
        return next();
    }
    console.log('User not authenticated, redirecting to login');
    res.status(401).redirect('/');
}

// Phục vụ loginpage.html làm trang mặc định
app.get('/', (req, res) => {
    console.log('Request to /, session:', req.session.user);
    if (req.session.user) {
        console.log('User already logged in, redirecting to index.html');
        return res.redirect('/index.html');
    }
    console.log('Serving loginpage.html');
    const loginPath = path.join(__dirname, 'public', 'loginpage.html');
    res.sendFile(loginPath, (err) => {
        if (err) {
            console.error('Error serving loginpage.html:', err);
            res.status(500).send('Error serving login page');
        }
    });
});

// Phục vụ các trang HTML (yêu cầu đăng nhập)
app.get('/index.html', isAuthenticated, (req, res) => {
    console.log('Serving index.html');
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/bangdieukhien.html', isAuthenticated, (req, res) => {
    console.log('Serving bangdieukhien.html');
    res.sendFile(path.join(__dirname, 'public', 'bangdieukhien.html'));
});

app.get('/bieudo.html', isAuthenticated, (req, res) => {
    console.log('Serving bieudo.html');
    res.sendFile(path.join(__dirname, 'public', 'bieudo.html'));
});

app.get('/lichsu.html', isAuthenticated, (req, res) => {
    console.log('Serving lichsu.html');
    res.sendFile(path.join(__dirname, 'public', 'lichsu.html'));
});

// API xử lý đăng nhập
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    console.log('Login attempt:', { username });
    if (!username || !password) {
        console.log('Missing username or password');
        return res.status(400).json({ message: 'Vui lòng nhập tên đăng nhập và mật khẩu' });
    }
    db.query('SELECT * FROM users WHERE username = ?', [username], (err, results) => {
        if (err) {
            console.error('Error querying user:', err);
            return res.status(500).json({ message: 'Lỗi server', details: err.message });
        }
        if (results.length === 0) {
            console.log('User not found');
            return res.status(401).json({ message: 'Tên đăng nhập hoặc mật khẩu không đúng' });
        }
        const user = results[0];
        bcrypt.compare(password, user.password, (err, isMatch) => {
            if (err) {
                console.error('Error comparing password:', err);
                return res.status(500).json({ message: 'Lỗi server', details: err.message });
            }
            if (!isMatch) {
                console.log('Password mismatch');
                return res.status(401).json({ message: 'Tên đăng nhập hoặc mật khẩu không đúng' });
            }
            req.session.user = { username: user.username };
            console.log('Login successful, redirecting to index');
            req.session.save((err) => {
                if (err) {
                    console.error('Error saving session:', err);
                    return res.status(500).json({ message: 'Lỗi lưu session' });
                }
                res.json({ message: 'Đăng nhập thành công', redirect: '/index.html' });
            });
        });
    });
});

// API kiểm tra trạng thái session
app.get('/check-session', (req, res) => {
    console.log('Session check, user:', req.session.user);
    if (req.session.user) {
        return res.json({ isLoggedIn: true });
    }
    res.json({ isLoggedIn: false });
});

// API đăng xuất
app.post('/logout', (req, res) => {
    console.log('Logout request received');
    req.session.destroy(err => {
        if (err) {
            console.error('Error logging out:', err);
            return res.status(500).json({ message: 'Lỗi đăng xuất', details: err.message });
        }
        console.log('Session destroyed, redirecting to login');
        res.json({ message: 'Đăng xuất thành công', redirect: '/' });
    });
});

// API lấy danh sách ngày
app.get('/getDates', isAuthenticated, (req, res) => {
    console.log('Fetching dates');
    const sql = `
        SELECT DISTINCT DATE_FORMAT(timestamp, '%Y-%m-%d') AS date FROM TrafficData
        UNION
        SELECT DISTINCT DATE_FORMAT(issued_at, '%Y-%m-%d') AS date FROM ControlCommands
        ORDER BY date DESC
    `;
    db.query(sql, (err, results) => {
        if (err) {
            console.error('Error fetching dates:', err);
            return res.status(500).json({ error: 'Lấy danh sách ngày thất bại', details: err.message });
        }
        console.log('Dates fetched:', results);
        res.json(results.map(row => row.date));
    });
});

// API lấy dữ liệu
app.get('/getData', isAuthenticated, (req, res) => {
    const { table, date, command_type } = req.query;
    console.log('Fetching data:', { table, date, command_type });
    let sql;
    const params = [1]; // branch_id = 1

    if (table === 'trafficdata') {
        sql = `
            SELECT 
                timestamp,
                avg_traffic_flow,
                avg_speed,
                motorcycle_count,
                car_count,
                bus_count,
                red_duration,
                yellow_duration,
                green_duration
            FROM TrafficData
            WHERE branch_id = ?
        `;
        if (date && date !== 'all') {
            sql += ` AND DATE(timestamp) = ?`;
            params.push(date);
        }
        sql += ` ORDER BY timestamp DESC`;
    } else if (table === 'controlcommands') {
        sql = `
            SELECT 
                command_type,
                red_duration,
                yellow_duration,
                green_duration,
                issued_at,
                time_slot
            FROM ControlCommands
            WHERE branch_id = ?
        `;
        if (date && date !== 'all') {
            sql += ` AND DATE(issued_at) = ?`;
            params.push(date);
        }
        if (command_type && command_type !== 'all') {
            sql += ` AND command_type = ?`;
            params.push(command_type);
        }
        sql += ` ORDER BY issued_at DESC`;
    } else {
        console.log('Invalid table:', table);
        return res.status(400).json({ error: 'Bảng không hợp lệ' });
    }

    db.query(sql, params, (err, results) => {
        if (err) {
            console.error('Error fetching data:', err);
            return res.status(500).json({ error: 'Lấy dữ liệu thất bại', details: err.message });
        }
        console.log('Data fetched:', results.length, 'rows');
        res.json(results);
    });
});

// API gửi lệnh điều khiển
app.post('/send-command', isAuthenticated, (req, res) => {
    const { command_type, red_time, yellow_time, green_time } = req.body;
    console.log('Sending command:', { command_type, red_time, yellow_time, green_time });
    const sql = `
        INSERT INTO ControlCommands (
            branch_id, command_type, red_duration, yellow_duration, green_duration, issued_at
        ) VALUES (?, ?, ?, ?, ?, NOW())
    `;
    db.query(sql, [1, command_type, red_time, yellow_time, green_time], (err) => {
        if (err) {
            console.error('Error saving command:', err);
            return res.status(500).json({ message: 'Lưu lệnh thất bại', details: err.message });
        }
        const payload = JSON.stringify({ red_time, yellow_time, green_time, command_type });
        mqttClient.publish('traffic/light/timings', payload, (err) => {
            if (err) {
                console.error('Error publishing MQTT:', err);
                return res.status(500).json({ message: 'Gửi lệnh MQTT thất bại', details: err.message });
            }
            console.log('Command sent successfully');
            res.json({ message: 'Lệnh được gửi thành công' });
        });
    });
});

// API lấy dữ liệu giao thông
app.get('/traffic-data', isAuthenticated, (req, res) => {
    console.log('Fetching traffic data');
    const sql = `
        SELECT 
            DATE_FORMAT(timestamp, '%d-%m-%Y %H:%i:%s') AS formatted_timestamp,
            avg_traffic_flow,
            avg_speed,
            motorcycle_count,
            car_count,
            bus_count,
            red_duration,
            yellow_duration,
            green_duration
        FROM TrafficData
        WHERE branch_id = 1
        ORDER BY timestamp DESC
        LIMIT 10
    `;
    db.query(sql, (err, results) => {
        if (err) {
            console.error('Error fetching traffic data:', err);
            return res.status(500).json({ error: 'Lấy dữ liệu thất bại', details: err.message });
        }
        console.log('Traffic data fetched:', results.length, 'rows');
        res.json(results);
    });
});

// API lấy tổng avg_traffic_flow theo giờ
app.get('/api/traffic-flow-by-hour', isAuthenticated, (req, res) => {
    const { date } = req.query;
    console.log('Fetching traffic flow by hour:', { date });
    let sql = `
        SELECT 
            HOUR(timestamp) AS hour,
            SUM(avg_traffic_flow) AS total_traffic_flow
        FROM TrafficData
        WHERE branch_id = 1
    `;
    const params = [];

    if (date && date !== 'all') {
        sql += ` AND DATE(timestamp) = ?`;
        params.push(date);
    }

    sql += `
        GROUP BY HOUR(timestamp)
        ORDER BY hour
    `;

    db.query(sql, params, (err, results) => {
        if (err) {
            console.error('Error fetching traffic flow by hour:', err);
            return res.status(500).json({ error: 'Lấy dữ liệu thất bại', details: err.message });
        }
        console.log('Traffic flow by hour fetched:', results);
        res.json(results);
    });
});

// API lấy trạng thái hiện tại
app.get('/getCurrentStatus', isAuthenticated, (req, res) => {
    console.log('Fetching current status');
    const { mode } = req.query;
    let sql = `
        SELECT 
            red_duration AS red_time,
            yellow_duration AS yellow_time,
            green_duration AS green_time,
            (red_duration + yellow_duration + green_duration + 1) AS signal_cycle,
            command_type
        FROM ControlCommands
        WHERE branch_id = 1
    `;
    const params = [];

    if (mode && mode !== 'yellow_all') {
        sql += ` AND command_type = ?`;
        params.push(mode);
    } else if (mode === 'yellow_all') {
        sql += ` AND command_type = 'yellow_all'`;
    }

    sql += ` ORDER BY issued_at DESC LIMIT 1`;

    db.query(sql, params, (err, results) => {
        if (err) {
            console.error('Error fetching current status:', err);
            return res.status(500).json({ error: 'Lấy trạng thái thất bại', details: err.message });
        }
        console.log('Current status fetched:', results[0]);
        res.json(results[0] || { red_time: 0, yellow_time: 0, green_time: 0, signal_cycle: 1, command_type: currentMode });
    });
});

// Hàm gửi dữ liệu đèn qua MQTT
function publishTimingsToESP(red_duration, yellow_duration, green_duration, command_type) {
    const payload = JSON.stringify({
        red_time: red_duration,
        yellow_time: yellow_duration,
        green_time: green_duration,
        command_type: command_type
    });
    mqttClient.publish('traffic/light/timings', payload, (err) => {
        if (err) {
            console.error('Error publishing timings to ESP8266:', err);
        } else {
            console.log('Timings published to ESP8266:', payload);
        }
    });
}

// API lưu chế độ
app.post('/saveMode', isAuthenticated, (req, res) => {
    const { mode } = req.body;
    console.log('Saving mode:', mode);
    // Cập nhật currentMode
    currentMode = mode;

    if (mode === 'manual') {
        // Xác định khung giờ hiện tại
        const now = new Date();
        const hours = now.getHours();
        let timeSlot;
        if (hours >= 0 && hours < 6) timeSlot = '0h-6h';
        else if (hours >= 6 && hours < 8) timeSlot = '6h-8h';
        else if (hours >= 8 && hours < 10) timeSlot = '8h-10h';
        else if (hours >= 10 && hours < 12) timeSlot = '10h-12h';
        else if (hours >= 12 && hours < 14) timeSlot = '12h-14h';
        else if (hours >= 14 && hours < 16) timeSlot = '14h-16h';
        else if (hours >= 16 && hours < 18) timeSlot = '16h-18h';
        else if (hours >= 18 && hours < 20) timeSlot = '18h-20h';
        else if (hours >= 20 && hours < 22) timeSlot = '20h-22h';
        else timeSlot = '22h-0h';

        // Lấy dữ liệu đèn mới nhất cho khung giờ
        const sqlSelect = `
            SELECT red_duration, yellow_duration, green_duration
            FROM ControlCommands
            WHERE branch_id = 1
            AND command_type = 'manual'
            AND time_slot = ?
            ORDER BY issued_at DESC
            LIMIT 1
        `;
        db.query(sqlSelect, [timeSlot], (err, results) => {
            if (err) {
                console.error('Error fetching latest manual command:', err);
                return res.status(500).json({ message: 'Lưu chế độ thất bại', details: err.message });
            }

            let red_duration = 0, yellow_duration = 0, green_duration = 0;
            if (results.length > 0) {
                red_duration = results[0].red_duration;
                yellow_duration = results[0].yellow_duration;
                green_duration = results[0].green_duration;
            }

            // Lưu chế độ manual và dữ liệu đèn
            const sqlInsert = `
                INSERT INTO ControlCommands (
                    branch_id, command_type, red_duration, yellow_duration, green_duration, issued_at, time_slot
                ) VALUES (?, ?, ?, ?, ?, NOW(), ?)
            `;
            db.query(sqlInsert, [1, mode, red_duration, yellow_duration, green_duration, timeSlot], (err) => {
                if (err) {
                    console.error('Error saving mode:', err);
                    return res.status(500).json({ message: 'Lưu chế độ thất bại', details: err.message });
                }
                console.log('Mode saved successfully with timings:', { red_duration, yellow_duration, green_duration });
                // Gửi dữ liệu đèn đến ESP8266
                publishTimingsToESP(red_duration, yellow_duration, green_duration, mode);
                res.json({ 
                    message: 'Chuyển chế độ manual thành công',
                    timings: { red_time: red_duration, yellow_time: yellow_duration, green_time: green_duration }
                });
            });
        });
    } else if (mode === 'auto') {
        // Lấy dữ liệu đèn mới nhất cho chế độ auto
        const sqlSelect = `
            SELECT red_duration, yellow_duration, green_duration
            FROM ControlCommands
            WHERE branch_id = 1
            AND command_type = 'auto'
            ORDER BY issued_at DESC
            LIMIT 1
        `;
        db.query(sqlSelect, (err, results) => {
            if (err) {
                console.error('Error fetching latest auto command:', err);
                return res.status(500).json({ message: 'Lưu chế độ thất bại', details: err.message });
            }
            let red_duration = 0, yellow_duration = 0, green_duration = 0;
            if (results.length > 0) {
                red_duration = results[0].red_duration;
                yellow_duration = results[0].yellow_duration;
                green_duration = results[0].green_duration;
            }
            // Gửi chế độ auto đến ESP8266
            publishTimingsToESP(red_duration, yellow_duration, green_duration, mode);
            res.json({ message: 'Chuyển chế độ auto thành công' });
        });
    } else {
        // Xử lý yellow_all
        const sql = `
            INSERT INTO ControlCommands (
                branch_id, command_type, red_duration, yellow_duration, green_duration, issued_at
            ) VALUES (?, ?, 0, 0, 0, NOW())
        `;
        db.query(sql, [1, mode], (err) => {
            if (err) {
                console.error('Error saving mode:', err);
                return res.status(500).json({ message: 'Lưu chế độ thất bại', details: err.message });
            }
            console.log('Mode saved successfully');
            // Gửi chế độ yellow_all đến ESP8266
            publishTimingsToESP(0, 0, 0, mode);
            res.json({ message: 'Lưu chế độ thành công' });
        });
    }
});

// API lấy chế độ hiện tại
app.get('/getMode', isAuthenticated, (req, res) => {
    console.log('Fetching current mode:', currentMode);
    res.json({ mode: currentMode });
});

// API lưu dữ liệu điều khiển
app.post('/save', isAuthenticated, (req, res) => {
    const data = req.body;
    console.log('Saving control data:', data);
    const sql = `
        INSERT INTO ControlCommands (
            branch_id, command_type, red_duration, yellow_duration, green_duration, issued_at, time_slot
        ) VALUES (?, ?, ?, ?, ?, NOW(), ?)
    `;
    const queries = data.map(row => {
        return new Promise((resolve, reject) => {
            db.query(sql, [1, 'manual', row.red_time, row.yellow_time, row.green_time, row.slot], (err) => {
                if (err) reject(err);
                else resolve();
            });
        });
    });

    Promise.all(queries)
        .then(() => {
            console.log('Control data saved successfully');
            // Xác định khung giờ hiện tại
            const now = new Date();
            const hours = now.getHours();
            let timeSlot;
            if (hours >= 0 && hours < 6) timeSlot = '0h-6h';
            else if (hours >= 6 && hours < 8) timeSlot = '6h-8h';
            else if (hours >= 8 && hours < 10) timeSlot = '8h-10h';
            else if (hours >= 10 && hours < 12) timeSlot = '10h-12h';
            else if (hours >= 12 && hours < 14) timeSlot = '12h-14h';
            else if (hours >= 14 && hours < 16) timeSlot = '14h-16h';
            else if (hours >= 16 && hours < 18) timeSlot = '16h-18h';
            else if (hours >= 18 && hours < 20) timeSlot = '18h-20h';
            else if (hours >= 20 && hours < 22) timeSlot = '20h-22h';
            else timeSlot = '22h-0h';

            // Tìm dữ liệu đèn của khung giờ hiện tại
            const row = data.find(r => r.slot === timeSlot);
            if (row) {
                // Gửi dữ liệu đèn đến ESP8266
                publishTimingsToESP(row.red_time, row.yellow_time, row.green_time, 'manual');
            }
            res.json({ message: 'Lưu dữ liệu thành công' });
        })
        .catch(err => {
            console.error('Error saving data:', err);
            res.status(500).json({ message: 'Lưu dữ liệu thất bại', details: err.message });
        });
});

// API lấy dữ liệu manual mới nhất cho mỗi time_slot
app.get('/getLatestManualCommands', isAuthenticated, (req, res) => {
    console.log('Fetching latest manual commands');
    const sql = `
        SELECT 
            red_duration,
            yellow_duration,
            green_duration,
            time_slot
        FROM ControlCommands
        WHERE branch_id = 1
        AND command_type = 'manual'
        AND time_slot IS NOT NULL
        AND (time_slot, issued_at) IN (
            SELECT time_slot, MAX(issued_at)
            FROM ControlCommands
            WHERE branch_id = 1
            AND command_type = 'manual'
            AND time_slot IS NOT NULL
            GROUP BY time_slot
        )
    `;
    db.query(sql, (err, results) => {
        if (err) {
            console.error('Error fetching latest manual commands:', err);
            return res.status(500).json({ error: 'Lấy dữ liệu thất bại', details: err.message });
        }
        console.log('Latest manual commands fetched:', results);
        res.json(results);
    });
});

// Khởi động server
app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});