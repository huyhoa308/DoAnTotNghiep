import serial
import time
from datetime import datetime

# Cấu hình cổng UART
SERIAL_PORT = "COM6"  # Thay bằng cổng thực tế
BAUD_RATE = 115200
TIMEOUT = 5  # Tăng timeout lên 10 giây

def log_with_timestamp(message):
    timestamp = "[" + datetime.now().strftime("%H:%M:%S.%f")[:-3] + "]"
    print(f"{timestamp} {message}")

def send_traffic_data(ser, green_time, avg_traffic_flow, avg_speed, motorcycle_count, car_count, bus_count):
    try:
        # Xóa bộ đệm trước khi gửi
        ser.flushInput()
        ser.flushOutput()

        # Tạo và gửi gói tin
        packet = f"{green_time},{avg_traffic_flow:.1f},{avg_speed:.1f},{motorcycle_count},{car_count},{bus_count}\n"
        ser.write(packet.encode())
        log_with_timestamp(f"Sent: {packet.strip()}")

        # Đọc ACK với timeout
        start_time = time.time()
        while time.time() - start_time < TIMEOUT:
            if ser.in_waiting > 0:
                response = ser.readline().decode().strip()
                log_with_timestamp(f"Received: {response}")
                return True
            time.sleep(0.01)  # Giảm tải CPU
        log_with_timestamp("No ACK received within timeout")
        return False

    except serial.SerialException as e:
        log_with_timestamp(f"Serial error: {e}")
        return False

def main():
    data = {
        "green_time": 15,
        "avg_traffic_flow": 10.5,
        "avg_speed": 40.2,
        "motorcycle_count": 50,
        "car_count": 20,
        "bus_count": 5
    }

    # Mở cổng UART một lần
    try:
        ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=TIMEOUT)
        log_with_timestamp(f"Serial port {SERIAL_PORT} opened successfully")
        
        try:
            while True:
                send_traffic_data(
                    ser,
                    data["green_time"],
                    data["avg_traffic_flow"],
                    data["avg_speed"],
                    data["motorcycle_count"],
                    data["car_count"],
                    data["bus_count"]
                )
                time.sleep(15)
        except KeyboardInterrupt:
            log_with_timestamp("Program stopped by user")
        finally:
            ser.close()
            log_with_timestamp("Serial port closed")

    except serial.SerialException as e:
        log_with_timestamp(f"Failed to open serial port: {e}")

if __name__ == "__main__":
    main()
